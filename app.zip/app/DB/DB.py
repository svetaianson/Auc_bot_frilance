import pymysql.cursors
from app.helper.config import Config
conf = Config()
class User():
    def _get_connection_cursor():
        conn = pymysql.connect(host=conf.get_value('HOST'),
                             user=conf.get_value('USER'),
                             password=conf.get_value('PASSWORD'),
                             database=conf.get_value('DATABASE'),
                             cursorclass=pymysql.cursors.DictCursor)
        cursor = conn.cursor()
        return conn, cursor
    
    def is_user_admin(tg_id: int) -> bool:
        """
        `true` if the user is admin

        `false` if the user is not admin
        """
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `tg_id` = %s AND `status` = %s;", (str(tg_id), 'admin'))
            if len(cursor.fetchall()) != 0:
                return True
        finally:
            conn.commit()
            cursor.close()
            conn.close()
        return False

    def get_admins():
        '''
        Возвращает все admins из таблицы `user` 
        '''
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `status` = %s;", ('admin', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_banned():
        '''
        Возвращает все admins из таблицы `user` 
        '''
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `status` = %s;", ('banned', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_users():
        '''
        Возвращает всех из таблицы `user` 
        '''
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `status`!= %s;", ('banned', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_users_tg_id():
        '''
        Возвращает всех из таблицы `user` 
        '''
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT id, tg_id FROM `user` WHERE `status`!= %s;", ('banned', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    def update_user_currency(tg_id: int, new_currency: str):
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute(
                "UPDATE user SET currency = %s WHERE tg_id = %s AND status != %s;",
                (new_currency, str(tg_id), 'banned')
            )
            conn.commit()  # Зафиксировать изменения в базе данных
        except Exception as e:
            print(f"Ошибка при обновлении валюты: {e}")
            conn.rollback()  # В случае ошибки откатить изменения
        finally:
            cursor.close()  # Закрыть курсор
            conn.close()    # Закрыть соединение с базой данных

    def get_user_by_tg_id(tg_id):
        '''
        Возвращает все значения из таблицы `user`
        '''
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `tg_id` = %s AND `status` != %s;", (str(tg_id), 'banned'))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_user_by_tg_link(tg_id):
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `tg_link` = %s AND `status` != %s;", (str(tg_id), 'banned'))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_user_by_id(id):
        '''
        Возвращает все значения из таблицы `user`
        '''
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `id` = %s AND `status` != %s;", (str(id), 'banned'))
            return cursor.fetchall()
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    def create_user(
            tg_id: int,
            tg_link: str,
            lang: str,
            carency: str,
            status: str = 'user'
    ) -> None:
        '''
        Добавляет нового пользователя в таблицу `user`
        '''
        
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("INSERT INTO `user` (`tg_id`, `tg_link`, `lang`, `carency`, `status`) VALUES (%s, %s, %s, %s, %s);",
                        (tg_id, tg_link, lang, carency, status))
        except BaseException:
            pass
        finally:
            conn.commit()
            cursor.close()
            conn.close()
        return
    
    def change_language(tg_id: int, lang_code: str = None) -> None:
        '''
        Изменяет язык пользователя
        '''
        
        try:
            conn, cursor = User._get_connection_cursor()
            if lang_code:
                new_lang = lang_code
            else:
                user = User.get_user_by_tg_id(tg_id)
                lang = user[0]['lang']
                new_lang = 'ru' if lang == 'en' else 'en'
            cursor.execute("UPDATE `user` SET `lang` = %s WHERE `tg_id` = %s;", (new_lang, tg_id))
        except BaseException:
            pass
        finally:
            conn.commit()
            cursor.close()
            conn.close()
        return
    def change_curra(tg_id: int, lang_code: str = None) -> None:
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("UPDATE `user` SET `carency` = %s WHERE `tg_id` = %s;", (lang_code, tg_id))
        except BaseException:
            pass
        finally:
            conn.commit()
            cursor.close()
            conn.close()
        return
    def status_change(tg_id: int, id: int, status: str) -> None:
        '''
        Изменяет статус пользователя
        '''
        
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("UPDATE `user` SET `status` = %s WHERE `id` = %s;", (status, str(id)))
        except BaseException:
            pass
        finally:
            conn.commit()
            cursor.close()
            conn.close()
        return
    
    def status_change_by_nickname(tg_id: int, nickname: str, status: str) -> None:
        '''
        Изменяет статус пользователя
        '''
        try:
            conn, cursor = User._get_connection_cursor()
            cursor.execute("UPDATE `user` SET `status` = %s WHERE `tg_link` = %s;", (status, nickname))
            cursor.execute("SELECT * FROM `user` WHERE `tg_link` = %s;", (nickname, ))
            user = cursor.fetchall()
        except BaseException:
            pass
        finally:
            conn.commit()
            cursor.close()
            conn.close()
        return user
    def current_by_id(tg_id: int):
        try:
            conn, cursor = User._get_connection_cursor()
            query = "SELECT carency FROM user WHERE tg_id = %s;"
            cursor.execute(query, (tg_id,))
            result = cursor.fetchone()
            if(result['carency']=="E"):
                return 1.14
        except BaseException:
            pass
        return 1

class Auction():
    def _get_connection_cursor():
        conn = pymysql.connect(host=conf.get_value('HOST'),
                             user=conf.get_value('USER'),
                             password=conf.get_value('PASSWORD'),
                             database=conf.get_value('DATABASE'),
                             cursorclass=pymysql.cursors.DictCursor)
        cursor = conn.cursor()
        return conn, cursor
    
    def get_opened_auctions():
        """
        Возвращает все аукционы в статусе `opened`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction` WHERE `status` = %s;", ('opened', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_closed_auctions():
        """
        Возвращает все аукционы в статусе `closed`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction` WHERE `status` = %s;", ('closed', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()

    def get_opened_auctions_by_type(type: str):
        """
        Возвращает все аукционы в статусе `opened`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction` WHERE `status` = %s AND `type` = %s;", ('opened', str(type)))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_time_auctions_by_id(auction_id: int):
        """
        Возвращает время до конца из таблицы `auction` по его `id`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT SEC_TO_TIME(TIMESTAMPDIFF(SECOND, CURRENT_TIMESTAMP(), TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start))) as left_time FROM `auction` WHERE `id` = %s;", (str(auction_id), ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_auction_by_id(auction_id: int):
        """
        Возвращает значения из таблицы `auction` по его `id`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction` WHERE `id` = %s;", (str(auction_id), ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_opened_auction_by_id(auction_id: int):
        """
        Возвращает значения из таблицы `auction` по его `id` открытые
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction` WHERE `id` = %s AND `status` = %s;", (str(auction_id), 'opened'))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_auction_by_id_with_bid(auction_id: int):
        """
        Возвращает значения из таблицы `auction` по его `id` со ставками
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM auction a LEFT JOIN bid b ON a.id = b.auction_id WHERE a.id = %s ORDER BY money DESC;", (str(auction_id), ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_auction_by_user_id(tg_id: int):
        """
        Возвращает значения из `auction` по `tg_id` пользователя
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `tg_id` = %s;", (str(tg_id), ))
            user_id = cursor.fetchall()[0]['id']
            cursor.execute("SELECT * FROM `auction` WHERE `status` != %s;", ('deleted', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_auction_by_status_pay():
        """
        Возвращает значения из `auction` по `tg_id` пользователя
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            # cursor.execute("SELECT * FROM `user` WHERE `tg_id` = %s;", (str(tg_id), ))
            # user_id = cursor.fetchall()[0]['id']
            cursor.execute("SELECT * FROM `auction` WHERE `statusPay` = %s;", ('active', ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def delete_auction(auction_id: int):
        """
        Удаляет аукцион по его `id`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("UPDATE `auction` SET `status` = 'deleted' WHERE `id` = %s;", (str(auction_id), ))
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return
    
    def open_auction_by_id(auction_id: int) -> None:
        """
        Открывает аукцион по его `id`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("update auction a set status = 'opened', time_start = CURRENT_TIMESTAMP(), time_update = CURRENT_TIMESTAMP() \
                            where a.id = %s and \
                            (select COUNT(*) FROM (SELECT * FROM auction) AS B  WHERE B.type = (SELECT type FROM (SELECT * FROM auction) as C WHERE id = %s) AND B.status = %s) < 5", 
                            (str(auction_id), str(auction_id), 'opened'))
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return
    
    def create_auction(
                       created_by: int,
                       picture: str,
                       name: str,
                       type: str,
                       volume: float,
                       abv: float,
                       country_ru: str,
                       country_en: str,
                       brand: str,
                       produser: str,
                       description_ru: str,
                       description_en: str,
                       price: float,
                       time_leinght
    ) -> int:
        auction_id = None
        print(111)
        try:
            user = User.get_user_by_tg_id(created_by)
            created_by = user[0]['id'] if len(user)!= 0 else 0
            conn, cursor = Auction._get_connection_cursor()
            print("y8")
            cursor.execute("INSERT INTO `auction` (`created_by`, `picture`, `name`, \
                           `type`, `volume`, `abv`, `country_ru`, `country_en`, `brand`, `produser`, \
                           `description_ru`, `description_en`, `price`, `time_leinght`, `status`) \
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);",
                            (created_by,
                             picture,
                             name,
                             type,
                             volume,
                             abv,
                             country_ru,
                             country_en,
                             brand,
                             produser,
                             description_ru,
                             description_en,
                             price,
                             time_leinght,
                             'created'))
            conn.commit()
            print("y9")
            auction_id = cursor.lastrowid
        except BaseException as e:
            print(e)
        finally:
            cursor.close()
            conn.close()
        return auction_id
    
    def update_auction(auction_id: int,
                       to_update: str,
                       value: str) -> int:
        """
        Обновляет аукцион по его `id`
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            match to_update:
                case 'picture':
                    to_update = 'picture'
                case 'description':
                    to_update = 'description'
                case 'price':
                    to_update = 'price'
                case 'time_leinght':
                    to_update = 'time_leinght'
                case 'statusPay':
                    to_update = 'statusPay'
                case 'last_message_id':
                    to_update = 'last_message_id'
                case _:
                    return
            cursor.execute("UPDATE `auction` SET `" + to_update + "` = %s WHERE `id` = %s;",
                            (value, auction_id))
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return 
    
    def update_payment_auction(
        auction_id: int,
        invoice_id: int,
        asset: str,
        amount: str,
        payment_url: str
    ) -> int:
        """
        Обновляет аукцион по его `id` (только поля для оплаты)
        """
        try:
            conn, cursor = Auction._get_connection_cursor()

            cursor.execute(
                "UPDATE `bank` SET `invoice_id` = %s, `asset` = %s, `amount` = %s, `payment_url` = %s, time_invoice = CURRENT_TIMESTAMP() WHERE `id` = %s;",
                (invoice_id, asset, amount, payment_url, auction_id)
            )
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return 
    
    def update_status_auction(
        auction_id: int,
        invoice_id: int,
        asset: str,
        statusPay: str,
        payment_url: str
    ) -> int:
        """
        Обновляет аукцион по его `id` (только поля для оплаты)
        """
        try:
            conn, cursor = Auction._get_connection_cursor()

            cursor.execute(
                "UPDATE `auction` SET `invoice_id` = %s, `asset` = %s, `statusPay` = %s, `payment_url` = %s WHERE `id` = %s;",
                (invoice_id, asset, statusPay, payment_url, auction_id)
            )
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return 
    
    def expired_auction():
        """
        Закрывает все аукционы
        """
        auctions = []
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT `id` FROM `auction` WHERE TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start) < NOW() AND `status`='closed';")
            auctions = cursor.fetchall()
            cursor.execute("UPDATE `auction` SET `statusPay`  = 'closed' WHERE TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start) < NOW() AND `status` = 'closed';")
            
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return auctions

    
class Bid():
    def _get_connection_cursor():
        conn = pymysql.connect(host=conf.get_value('HOST'),
                             user=conf.get_value('USER'),
                             password=conf.get_value('PASSWORD'),
                             database=conf.get_value('DATABASE'),
                             cursorclass=pymysql.cursors.DictCursor)
        cursor = conn.cursor()
        return conn, cursor
    
    def add_bid(auction_id: int, tg_id: int, money: int) -> bool:
        """
        Добавляет новую ставку в таблицу `bid`
        """
        conn, cursor = Bid._get_connection_cursor()
        try:
            cursor.execute("SELECT TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start) > NOW() as `result` FROM `auction` WHERE `id` = %s;", (str(auction_id), ))
            results = cursor.fetchall()
            if len(results) > 0 and results[0]['result'] != 0:
                cursor.execute("INSERT INTO `bid` (`auction_id`, `user_id`, `money`, `time_bid`) VALUES (%s, (SELECT `id` FROM `user` WHERE `tg_id` = %s), \
                                %s, CURRENT_TIMESTAMP());",
                            (str(auction_id), str(tg_id), money))
                cursor.execute("SELECT TIMESTAMPDIFF(SECOND, CURRENT_TIMESTAMP(), TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start)) as `result` FROM `auction` WHERE `id` = %s;", (str(auction_id), ))
                try:
                    time = cursor.fetchall()[0]['result']
                    if time < conf.get_value("ANTISNIPER_FIX"):
                        cursor.execute("UPDATE `auction` SET `time_leinght` = ADDTIME(`time_leinght`, SEC_TO_TIME(%s)) WHERE `id` = %s;", (str(conf.get_value("ANTISNIPER")), str(auction_id), ))
                except BaseException:
                    pass
                conn.commit()
                done = True
        except BaseException:
            done = False
        finally:
            cursor.close()
            conn.close()
        return done
    
    def get_bids_by_auction_id(auction_id: int):
        """
        Возвращает все ставки по `auction_id`
        """
        try:
            conn, cursor = Bid._get_connection_cursor()
            cursor.execute("SELECT a.id, `money`, `tg_link` FROM `bid` a LEFT JOIN `user` b ON a.user_id = b.id WHERE `auction_id` = %s ORDER BY money ASC;", (str(auction_id), ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_max_bid_by_auction_id(auction_id: int):
        """
        Возвращает все ставки по `auction_id`
        """
        try:
            conn, cursor = Bid._get_connection_cursor()
            cursor.execute("SELECT * FROM bid WHERE money = (select max(money) from bid) AND auction_id = %s;", (str(auction_id), ))
            return cursor.fetchone()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def get_bid_by_id(bid_id: int):
        """
        Возвращает ставку по `id`
        """
        try:
            conn, cursor = Bid._get_connection_cursor()
            cursor.execute("SELECT * FROM `bid` WHERE `id` = %s;", (str(bid_id), ))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def delete_bid_by_id(bid_id: int):
        """
        Удаляет ставку по `id`
        """
        try:
            conn, cursor = Bid._get_connection_cursor()
            cursor.execute("DELETE FROM `bid` WHERE `id` = %s;", (str(bid_id), ))
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return
    
    def delete_bid_by_user_and_auction(user_id: int, auction_id: int):
        """
        Удаляет ставку по `id`
        """
        try:
            conn, cursor = Bid._get_connection_cursor()
            cursor.execute("DELETE FROM `bid` WHERE `user_id` = (SELECT `id` FROM `user` WHERE `tg_id` = %s) AND `auction_id` = %s;", (str(user_id), str(auction_id)))
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return
    
    def get_bid_by_tg_id(tg_id: int, auction_id: int):
        """
        Возвращает ставку по `tg_id` пользователя
        """
        try:
            conn, cursor = Bid._get_connection_cursor()
            cursor.execute("SELECT * FROM `bid` WHERE `user_id` = (SELECT `id` FROM `user` WHERE `tg_id` = %s) AND `auction_id` = %s ORDER BY `money` DESC;", (str(tg_id), str(auction_id)))
            return cursor.fetchall()
        finally:
            conn.commit()
            cursor.close()
            conn.close()
    
    def update_bid_by_tg_id(tg_id: int, auction_id: int, money: int):
        try:
            conn, cursor = Bid._get_connection_cursor()
            done = False
            cursor.execute("UPDATE `bid` SET money = %s WHERE `user_id` = (SELECT `id` FROM `user` WHERE `tg_id` = %s) AND `auction_id` = %s;", (str(money), str(tg_id), str(auction_id)))
            conn.commit()
            done = True
        except BaseException as e:
            done = False
        finally:
            cursor.close()
            conn.close()
        return done
    
        
    
class Bank:
    def _get_connection_cursor():
        conn = pymysql.connect(host=conf.get_value('HOST'),
                             user=conf.get_value('USER'),
                             password=conf.get_value('PASSWORD'),
                             database=conf.get_value('DATABASE'),
                             cursorclass=pymysql.cursors.DictCursor)
        cursor = conn.cursor()
        return conn, cursor
    
    def create_bank(auction_id: int, tg_id: int):
        """
        Добавляет новую ставку в таблицу `bid`
        """
        
        try:
            conn, cursor = Bank._get_connection_cursor()
            cursor.execute("SELECT TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start) > NOW() as `result` FROM `auction` WHERE `id` = %s;", (str(auction_id), ))
            results = cursor.fetchall()
            if len(results) > 0 and results[0]['result'] != 0:
                cursor.execute("INSERT INTO `bank` (`auction_id`, `user_id`) VALUES (%s, %s);", (auction_id, tg_id))
                conn.commit()
                done = True
        except BaseException:
            done = False
        finally:
            cursor.close()
            conn.close()
        return done
    
    def get_bank_by_auction(auction_id: int):
        """
        return by `auc_id`
        """
        try:
            conn, cursor = Bank._get_connection_cursor()
            cursor.execute("SELECT * FROM `bank` WHERE `auction_id` = %s;", (auction_id, ))
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()
    
    def get_bank_by_auction_and_user(auction_id: int, user_id: int):
        """
        return by `auc_id and user_id`
        """
        try:
            conn, cursor = Bank._get_connection_cursor()
            cursor.execute("SELECT * FROM `bank` WHERE `auction_id` = %s AND `user_id` = %s;", (auction_id, user_id))
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()
    
    def get_bank_by_status_pay():
        """
        Возвращает значения из `auction` по `tg_id` пользователя
        """
        try:
            conn, cursor = Auction._get_connection_cursor()
            cursor.execute("SELECT * FROM `bank` WHERE `statusPay` = %s;", ('active', ))
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()
    
    def get_paid_banks():
            """
            Возвращает оплаченные аукционы
            """
            auction = []
            try:
                conn, cursor = Bank._get_connection_cursor()
                cursor.execute("SELECT * FROM `bank` WHERE `statusPay` = %s;", ('paid', ))
                auction = cursor.fetchall()
            except BaseException:
                pass
            finally:
                cursor.close()
                conn.close()
            return auction
    
    def update_bank_status(id: int, status: str):
        """
        return by `auc_id and user_id`
        """
        try:
            conn, cursor = Bank._get_connection_cursor()
            if status == 'closed':
                cursor.execute("UPDATE `bank` SET `statusPay` = %s, `price` = 0 WHERE `id` = %s;", (status, id))
                conn.commit()
                done = True
            else:
                cursor.execute("UPDATE `bank` SET `statusPay` = %s WHERE `id` = %s;", (status, id))
                conn.commit()
                done = True
        except BaseException:
            done = False
        return done
    
    def update_bank(auction_id: int, user_id: int, balance: int):
        """
        return by `auc_id and user_id`
        """
        try:
            conn, cursor = Bank._get_connection_cursor()
            cursor.execute("UPDATE `bank` SET `balance` = %s WHERE `auction_id` = %s AND `user_id` = %s;", (balance, auction_id, user_id))
            conn.commit()
            done = True
        except BaseException:
            done = False
        return done
    
    def update_bank_by_id(id: int, balance: int):
        """
        return by `auc_id and user_id`
        """
        try:
            conn, cursor = Bank._get_connection_cursor()
            cursor.execute("UPDATE `bank` SET `balance` = %s WHERE `id` = %s;", (balance, id))
            conn.commit()
            done = True
        except BaseException:
            done = False
        return done
    
    def update_payment_bank(
        auction_id: int,
        user_id: int,
        invoice_id: int,
        asset: str,
        price: str,
        amount: str,
        payment_url: str
    ) -> int:
        """
        Обновляет аукцион по его `id` (только поля для оплаты)
        """
        try:
            conn, cursor = Auction._get_connection_cursor()

            cursor.execute(
                "UPDATE `bank` SET `invoice_id` = %s, `asset` = %s, price = %s, `amount` = %s, `payment_url` = %s, `statusPay` = 'active', time_invoice = CURRENT_TIMESTAMP() WHERE `auction_id` = %s AND `user_id` = %s;",
                (invoice_id, asset, price, amount, payment_url, auction_id, user_id)
            )
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return 
    
    def update_status_bank(
        auction_id: int,
        invoice_id: int,
        asset: str,
        statusPay: str,
        payment_url: str
    ) -> int:
        """
        Обновляет аукцион по его `id` (только поля для оплаты)
        """
        try:
            conn, cursor = Auction._get_connection_cursor()

            cursor.execute(
                "UPDATE `auction` SET `invoice_id` = %s, `asset` = %s, `statusPay` = %s, `payment_url` = %s WHERE `id` = %s;",
                (invoice_id, asset, statusPay, payment_url, auction_id)
            )
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return 

class Messages:
    def _get_connection_cursor():
        conn = pymysql.connect(host=conf.get_value('HOST'),
                             user=conf.get_value('USER'),
                             password=conf.get_value('PASSWORD'),
                             database=conf.get_value('DATABASE'),
                             cursorclass=pymysql.cursors.DictCursor)
        cursor = conn.cursor()
        return conn, cursor
    
    def add_message(auction_id: int, tg_id: int, message_id: int):
        """
        Добавляет new message в таблицу `auction_messages`
        """
        
        try:
            conn, cursor = Messages._get_connection_cursor()
            cursor.execute("INSERT INTO `auction_messages` (`auction_id`, `user_id`, `message_id`) VALUES (%s, %s, %s);",
                        (auction_id, tg_id, message_id))
            conn.commit()
            done = True
        except BaseException:
            done = False
        finally:
            cursor.close()
            conn.close()
        return done
    
    def get_message_by_auction():
        """
        return by `auc_id`
        """
        try:
            conn, cursor = Messages._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction_messages`", ())
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()
    def get_message_by_auction2(auction_id: int):
        """
        return by `auc_id`
        """
        try:
            conn, cursor = Messages._get_connection_cursor()
            cursor.execute("SELECT * FROM auction_messages WHERE auction_id = %s", (auction_id,))
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()
    def get_message_by_auction_and_user(auction_id: int, user_id: int):
        """
        return by `auc_id and user_id`
        """
        try:
            conn, cursor = Messages._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction_messages` WHERE `auction_id` = %s AND `user_id` = %s;", (auction_id, user_id))
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()
    
    def update_message(auction_id: int, user_id: int, message_id: int):
        """
        return by `auc_id and user_id`
        """
        try:
            conn, cursor = Messages._get_connection_cursor()
            cursor.execute("UPDATE `auction_messages` SET `message_id` = %s WHERE `auction_id` = %s AND `user_id` = %s;", (message_id, auction_id, user_id))
            conn.commit()
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()