from aiogram import Router, F
from aiogram.filters import Command
from aiogram.filters.callback_data import CallbackData, CallbackQuery
from aiogram.types import Message, ReplyKeyboardRemove, FSInputFile, InputMediaPhoto
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from app.helper.i18n import get_msg_lang
import asyncio
from queue import Queue
from threading import Thread
import re
import app.keyboards.for_user as kb_usr
import app.callbackdata.custom as cbd
import app.messages.for_user as msg
import app.messages.for_admin as msg_adm
from app.DB.DB import User, Auction, Bid, Messages, Bank
import pymysql.cursors
from app.helper.config import Config
from app.cryptoPay import cryptoPay
import time
import os
import requests
from datetime import datetime, timedelta
class AppContext:
    def __init__(self):
        res=requests.get(f'https://api.cryptomus.com/v1/exchange-rate/EUR/list')
        for course in res.json()['result']:
            if course['to'] == "USD":
                self.curse2 = float(course['course'])
        self.start=datetime.now()
    async def check_curse(self):
        res=requests.get(f'https://api.cryptomus.com/v1/exchange-rate/EUR/list')
        for course in res.json()['result']:
            if course['to'] == "USD":
                self.curse2 = float(course['course'])
app_context = AppContext()

conf = Config()
router = Router()
crypto = cryptoPay.Crypto()

STATIC_PATH = os.path.join(os.path.dirname(__file__), '../static/')

class AuctionControllerDB():
    def _get_connection_cursor():
        conn = pymysql.connect(host=conf.get_value('HOST'),
                             user=conf.get_value('USER'),
                             password=conf.get_value('PASSWORD'),
                             database=conf.get_value('DATABASE'),
                             cursorclass=pymysql.cursors.DictCursor)
        cursor = conn.cursor()
        return conn, cursor
    
    def get_min_time_to_update():
        """
        Возвращает минимальное время до обновления аукциона
        """
        conn, cursor = AuctionControllerDB._get_connection_cursor()
        cursor.execute("SELECT MIN(TIMESTAMPDIFF(SECOND, CURRENT_TIMESTAMP(), TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start))) AS `result` FROM `auction` WHERE `status`='opened';")
        return cursor.fetchall()[0]['result']
    
    def get_auction_by_update_date():
        """
        Возвращает значения из `auction`
        """
        auctions = []
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("SELECT * FROM auction WHERE time_update < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL %s MINUTE) AND status = 'opened';", (conf.get_value('UPDATE_INTERVAL')))
            auctions = cursor.fetchall()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return auctions
    
    def update_auction_update_date(id: int):
        """
        
        """
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("UPDATE auction SET time_update = CURRENT_TIMESTAMP() WHERE id = %s;", (id))
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()

    def update_auction_last_message(id: int, message_id: int):
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("UPDATE auction SET last_message_id = %s WHERE id = %s;", (message_id, id))
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
    
    def close_auction():
        """
        Закрывает все аукционы
        """
        auctions = []
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("SELECT `id` FROM `auction` WHERE TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start) < NOW() AND `status`='opened';")
            auctions = cursor.fetchall()
            cursor.execute("UPDATE `auction` SET `status`  = 'closed' WHERE TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght), time_start) < NOW() AND `status` = 'opened';")
            
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return auctions
    
    def expired_auction():
        """
        Возвращает все аукционы, в которых кончился срок оплаты
        """
        auctions = []
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("SELECT `id` FROM `auction` WHERE TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght) + %s, time_start) < NOW() AND `status`='closed' AND `statusPay` = 'active';", (conf.get_value('PAY_EXPARATION')))
            auctions = cursor.fetchall()
            cursor.execute("UPDATE `auction` SET `statusPay`  = 'closed' TIMESTAMPADD(SECOND, TIME_TO_SEC(time_leinght) + %s, time_start) < NOW() AND `status`='closed' AND `statusPay` = 'active';", (conf.get_value('PAY_EXPARATION')))
            
            conn.commit()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return auctions
    
    def get_losers_by_auction_id(auction_id: int):
        """
        Возвращает список пользователей, которые не смогли победить в аукционе
        """
        losers = []
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("SELECT DISTINCT `user_id`, user.tg_id FROM `bid` LEFT JOIN user ON user.id = `user_id` WHERE `auction_id` = %s AND \
                           `user_id` != (SELECT `user_id` FROM `bid` WHERE `auction_id` = %s ORDER BY `money` DESC LIMIT 1);;", (str(auction_id), str(auction_id)))
            losers = cursor.fetchall()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return losers
    

    def get_closed_auction():
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("SELECT * FROM `auction` WHERE `status` = %s;", ('closed', ))
            return cursor.fetchall()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()


    def get_max_bid(auction_id: int, user_id: int):
        """
        Возвращает список пользователей, которые не смогли победить в аукционе
        """
        losers = []
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("SELECT * FROM bid where money = (select max(money) from bid WHERE user_id = %s AND auction_id = %s);", (str(user_id), str(auction_id)))
            losers = cursor.fetchone()
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return losers
    
    def get_winner_by_auction_id(auction_id: int):
        """
        Возвращает пользователя, который победил в аукционе
        """
        winner = []
        money = 0
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("SELECT * FROM `user` WHERE `id` = (SELECT `user_id` FROM `bid` WHERE `auction_id` = %s ORDER BY `money` DESC LIMIT 1);", (str(auction_id), ))
            winner = cursor.fetchall()
            cursor.execute("SELECT `money` FROM `bid` WHERE `auction_id` = %s ORDER BY `money` DESC LIMIT 1;", (str(auction_id), ))
            money = cursor.fetchall()[0]['money']
        except BaseException:
            pass
        finally:
            cursor.close()
            conn.close()
        return winner, money
    
    def get_paid_auctions():
            """
            Возвращает оплаченные аукционы
            """
            auction = []
            try:
                conn, cursor = AuctionControllerDB._get_connection_cursor()
                cursor.execute("SELECT * FROM `auction` WHERE `statusPay` = %s;", ('paid', ))
                auction = cursor.fetchall()
            except BaseException:
                pass
            finally:
                cursor.close()
                conn.close()
            return auction
    
    def auction_to_archive() -> None:
        try:
            conn, cursor = AuctionControllerDB._get_connection_cursor()
            cursor.execute("UPDATE auction SET status = %s WHERE status = %s;", ('archive', 'closed'))
            conn.commit()
        except BaseException as e:
            print(f"An error occurred: {e}")
        finally:
            cursor.close()
            conn.close()


    def get_expired_auctions():
            """
            Возвращает оплаченные аукционы
            """
            auction = []
            try:
                conn, cursor = AuctionControllerDB._get_connection_cursor()
                cursor.execute("SELECT * FROM `auction` WHERE `statusPay` = %s;", ('expired', ))
                auction = cursor.fetchall()
            except BaseException:
                pass
            finally:
                cursor.close()
                conn.close()
            return auction
    
def controller(bot, loop):
    while True:
        time_to_close = AuctionControllerDB.get_min_time_to_update()
        time_to_close = time_to_close if time_to_close else 0
        auctions = AuctionControllerDB.close_auction()
        paidBanks = Bank.get_paid_banks()
        expired = AuctionControllerDB.get_closed_auction()
        update_auctions = AuctionControllerDB.get_auction_by_update_date()
        between_callback_checkInvoice(loop=loop)

        if len(expired) > 0:
            between_callback_expired2(expired, bot, loop=loop)

        if len(paidBanks) > 0:
            between_callback_paid(paidBanks, bot, loop=loop)

        between_callback_update(update_auctions, bot, loop=loop)

        if len(auctions) > 0:    
            between_callback(auctions, bot, loop=loop)
        if time_to_close < 10:
            time.sleep(1)
        else: 
            time.sleep(10)

def between_callback(*args, loop):
    asyncio.set_event_loop(loop)

    send_fut = asyncio.run_coroutine_threadsafe(send_notification(*args), loop)
    send_fut.result()

def between_callback_paid(*args, loop):
    asyncio.set_event_loop(loop)

    send_fut = asyncio.run_coroutine_threadsafe(send_paid(*args), loop)
    send_fut.result()
def between_callback_expired2(ex,bot,loop):
    asyncio.set_event_loop(loop)
    send_fut = asyncio.run_coroutine_threadsafe(between_callback_expired(ex,bot), loop)
    send_fut.result()
async def between_callback_expired(ex,bot):
    id_aucs=[]
    naz=[]
    winners=[]
    losers=[]
    admins=User.get_admins()
    for i in ex:
        id_aucs.append(i['id'])
        naz.append(i['name'])
        winners.append(AuctionControllerDB.get_winner_by_auction_id(i['id']))
        losers.append(AuctionControllerDB.get_losers_by_auction_id(i['id']))
    current_time=datetime.now()
    if current_time - app_context.start > timedelta(hours=1):
        app_context.start=datetime.now()
        app_context.check_curse()
    for i in range(len(winners)):
        if(winners[i][1]!=0):
            ost=(Bank.get_bank_by_auction_and_user(str(id_aucs[i]),winners[i][0][0]['tg_id']))[0]['balance']
            valuer=User.get_user_by_tg_id(winners[i][0][0]['tg_id'])[0]['carency']
            status = crypto.transfer("USDT", max(float(ost)-winners[i][1],0)*0.97, str(id_aucs[i]), str(winners[i][0][0]['tg_id']))
            await bot.send_message(chat_id=str(winners[i][0][0]['tg_id']),text=(get_msg_lang("win",winners[i][0][0]['tg_id'])%(naz[i],float(winners[i][1]) if valuer=="D" else round(float(winners[i][1])/app_context.curse2,2))))
            for j in range(len(admins)):
                text=get_msg_lang("admin23",admins[j]['tg_id'])
                await bot.send_message(chat_id=str(admins[j]['tg_id']),text=((text)%("@"+str(User.get_user_by_tg_id(winners[i][0][0]['tg_id'])[0]['tg_link']),naz[i])))
    for i in range(1,len(losers)):
        for j in losers[i]:
            await bot.send_message(chat_id=str(j[0][0]['tg_id']),
                            text=(get_msg_lang("los",j[0][0]['tg_id'])%(naz[i],j[1])))
    for h in id_aucs:
        mess=Messages.get_message_by_auction2(h)
        for i in mess:
            try:
                await bot.delete_message(chat_id=i['user_id'], message_id=i['message_id'])
            except:
                print(1)
    AuctionControllerDB.auction_to_archive()
def between_callback_update(*args, loop):
    asyncio.set_event_loop(loop)

    send_fut = asyncio.run_coroutine_threadsafe(update_auctions(*args), loop)
    send_fut.result()

# def between_callback_expired(*args, loop):
#     asyncio.set_event_loop(loop)

#     send_fut = asyncio.run_coroutine_threadsafe(send_expired(*args), loop)
#     send_fut.result()

def between_callback_checkInvoice(*args, loop):
    asyncio.set_event_loop(loop)

    send_fut = asyncio.run_coroutine_threadsafe(crypto.checkInvoices(), loop)
    send_fut.result()

    time.sleep(20)

async def send_notification(auction, bot):
    if conf.get_value('LOOSE_NOTIFICATION'):
        users = AuctionControllerDB.get_losers_by_auction_id(auction[0]['id'])
        auction_name = Auction.get_auction_by_id(auction[0]['id'])
        auction_name = auction_name[0]['name'] if len(auction_name) > 0 else ''
        for user in users:
            try:
                await bot.send_message(user['tg_id'], 
                                    msg.losers_msg(user['tg_id'], auction_name),
                                    reply_markup=kb_usr.get_back_kb(user['tg_id']))
                max_bid = AuctionControllerDB.get_max_bid(auction[0]['id'], user['id'])
                if max_bid:
                    bank = Bank.get_bank_by_auction_and_user(auction[0]['id'], user['id'])
                    Bank.update_bank(auction[0]['id'], user['id'], int(bank[0]['balance'] + int(max_bid['money'])))

            except BaseException:
                pass

    if conf.get_value('WIN_NOTIFICATION'):
        user, money = AuctionControllerDB.get_winner_by_auction_id(auction[0]['id'])
        if len(user) > 0:
            try:
                await bot.send_message(user[0]['tg_id'], 
                                    msg.winners_msg(user[0]['tg_id'], money),
                                    reply_markup=kb_usr.get_back_kb(auction[0]['id'], user[0]['tg_id'], money))
                admins = User.get_admins()
                for admin in admins:
                    try:
                        await bot.send_message(admin['tg_id'], 
                                    msg_adm.winner_msg(admin['tg_id'], money, user[0]['tg_link']))
                    except BaseException:
                        pass
        
            except BaseException:
                pass

async def send_paid(banks, bot):
    for bank in banks:
        user = User.get_user_by_tg_id(bank['user_id'])
        # auction = Auction.get_auction_by_id(bank['auction_id'])
        # auction_name = auction[0]['name'] if len(auction[0]['name']) > 0 else ''
        try:
            await bot.send_message(user[0]['tg_id'], 
                                    msg.successful_payment_msg(user[0]['tg_id'], bank['price']),
                                    reply_markup=kb_usr.get_back_kb(user[0]['tg_id']))
            Bank.update_bank_by_id(bank['id'], int(bank['price']) + int(bank['balance']))
            Bank.update_bank_status(bank['id'], 'closed')
        except BaseException as e:
            print(e)

async def update_auctions(auctions, bot):
    messages = Messages.get_message_by_auction()
    opened=Auction.get_opened_auctions()
    op=[i['id'] for i in opened]
    time_d=[i['time_start'] for i in opened]
    pic=[i['picture'] for i in opened]
    pop=[i['time_leinght'] for i in opened]
    get=[]
    for i in range(len(messages)):
        if(messages[i]['auction_id'] in op):
            if(pic[op.index(messages[i]['auction_id'])]==None):
                messages[i]['picture']=None
                messages[i]['time']=(time_d[op.index(messages[i]['auction_id'])]+pop[op.index(messages[i]['auction_id'])]-datetime.now())
                get.append(messages[i])
            else:
                messages[i]['picture']=pic[op.index(messages[i]['auction_id'])]
                messages[i]['time']=(time_d[op.index(messages[i]['auction_id'])]+pop[op.index(messages[i]['auction_id'])]-datetime.now())
                get.append(messages[i])
    if len(messages) == 0:
        return
    current_time=datetime.now()
    if current_time - app_context.start > timedelta(hours=1):
        app_context.start=datetime.now()
        app_context.check_curse()
    for message in get:
        try:
            if message['picture'] == None: # Аукцион без фото
                newMess = msg.msg_auction(message['user_id'], message['auction_id'], app_context.curse2,str(message['time'])[:-10])
                media = InputMediaPhoto(media=photo, caption=newMess)
                await bot.edit_message_media(
                    chat_id=message['user_id'],
                    message_id=message['message_id'],
                    media=media,
                    reply_markup=kb_usr.get_auction_detail_kb(message['user_id'], message['id'])
                )
                AuctionControllerDB.update_auction_update_date(message['id'])
            elif message['picture'] != None: # Аукцион с фото
                photo = FSInputFile(
                    os.path.join(STATIC_PATH, 
                                message['picture'])
                )
                current_time = datetime.now()
                if current_time - app_context.start > timedelta(hours=1):
                    app_context.start=datetime.now()
                    await app_context.check_curse()
                newMess = msg.msg_auction(message['user_id'], message['auction_id'],app_context.curse2,str(message['time'])[:-10])
                media = InputMediaPhoto(media=photo, caption=newMess)
                await bot.edit_message_media(
                    chat_id=message['user_id'],
                    message_id=message['message_id'],
                    media=media,
                    reply_markup=kb_usr.get_auction_detail_kb(message['user_id'], message['auction_id'])
                )
                AuctionControllerDB.update_auction_update_date(message['id'])
        except BaseException:
            pass
# async def send_expired(auction, bot):
#     winner, money = AuctionControllerDB.get_winner_by_auction_id(auction[0]['id'])
#     lossers = AuctionControllerDB.get_losers_by_auction_id(auction[0]['id'])
#     print(winner, lossers)
#     second_place = User.get_user_by_id(lossers[0]['user_id'])[0]['tg_link'] if len(lossers) > 0 else ''
#     third_place = User.get_user_by_id(lossers[0]['user_id'])[0]['tg_link'] if len(lossers) > 1 else ''
#     try:
#         admins = User.get_admins()
#         for admin in admins:
#             try:
#                 await bot.send_message(admin['tg_id'], 
#                 msg_adm.expired_payment_msg(winner[0]['tg_id'], winner[0]['tg_link'], second_place, third_place, money))
#             except BaseException:
#                 pass
#         Auction.update_auction(auction[0]['id'], 'statusPay', 'closed')
#     except BaseException:
#         pass